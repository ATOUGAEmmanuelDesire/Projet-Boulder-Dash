/**
 * @author FOTSO  Emmanuel Jordan
 * @groupe10
 */
package main;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

import contract.IBoulderDashController;
import contract.IModel;
import controller.Controller;
import model.BoulderDashModel;
import model.DAO.DAOMap;
import view.View;

import javax.swing.*;

/**
 * The Class Main.
 *
 * @author EmmanuelJordan
 */
public abstract class Main {


    private static final String[] filenames = new String[] {"Lv1.txt", "sprites/background.png", "sprites/boulder.png", "sprites/diamond.png", "sprites/door.png", "sprites/greenMonster.png", "sprites/ground.png", "sprites/pDead.png", "sprites/pDown.png", "sprites/pLeft.png", "sprites/pNope.png", "sprites/pRight.png", "sprites/pUp.png", "sprites/pWin.png", "sprites/redMonster.png", "sprites/wall.png"};

    /**
     * The main method.
     *
     */
    public static void main(final String[] args) {
        checkFiles();
        menu();
        game();
        Controller.music();

        System.exit(0);
    }



    static void checkFiles() {
        File file;
        for (String filename : filenames) {
            file = new File(filename);
            if (!file.exists()){
                JOptionPane.showMessageDialog(null, "File \"" + filename + "\" is missing.\nPlease put the file back in its place and then restart.", "BoulderDash - Error", JOptionPane.ERROR_MESSAGE);
                System.exit(0);
                return;
            }
        }
    }

    static void menu() {

        int choice = JOptionPane.showInternalConfirmDialog(null, "Do you want to start the game?", "BloulderDash - Menu",JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE);
        DAOMap databaseConnection;
        Object[] maps;

        if (choice==0) {
            try {
                databaseConnection = new DAOMap();
            } catch (ClassNotFoundException | SQLException e) {
                JOptionPane.showMessageDialog(null, "Let's go !", "BoulderDash", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                maps = databaseConnection.getLevels();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Let's go", "BoulderDash", JOptionPane.PLAIN_MESSAGE);
                return;
            }

            String map = (String)JOptionPane.showInputDialog(null, "Which map do you want to load?", "BoulderDash - Load map", JOptionPane.PLAIN_MESSAGE, null, maps, maps[0]);

            if (map != null) {
                try {
                    databaseConnection.loadlevel(filenames[0], map);
                } catch ( SQLException | IOException e) {
                    JOptionPane.showMessageDialog(null, "Can't load map into map file!\nLaunching game without loading a new map.", "BoulderDash - Error", JOptionPane.PLAIN_MESSAGE);
                }
            }

        }
    }

    static void game() {
        boolean hasWon = false;
        do {

            IModel model = new BoulderDashModel(filenames[0], 1, 1);

            if (model.getMap().isCorrect()) {
                View view = new View(model.getMap(), model.getMyPlayer());
                IBoulderDashController controller = new Controller(view, model);
                view.setOrderPerformer(controller.getOrderPerformer());
                controller.play();


            }
        }while (true);

    }
}