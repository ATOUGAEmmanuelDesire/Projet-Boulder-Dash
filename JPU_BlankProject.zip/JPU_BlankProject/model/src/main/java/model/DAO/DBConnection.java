package model.DAO;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * @author Laetitia
 *
 */
public class DBConnection {

    /**
     * the database url
     */
    private static final String URL = "jdbc:mysql://localhost:3306/boulder_dash_2";
    /**
     * the user
     */
    private static final String USER = "root";
    /**
     * the password
     */
    private static final String PASSWD = "emma@2017#2004#";

    private Connection connection = null;

    private DBConnection INSTANCE;

    /**
     * Connects to the database
     */
    public void connect() throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        connection = DriverManager.getConnection(URL, USER, PASSWD);
    }

    /**
     * Gets the connection
     */
    public Connection getConnection() {
        return connection;
    }

    public String getURL() {
        return null;
    }

    public String getUSER() {
        return null;
    }

    public String getPASSWD() {
        return null;
    }
}

