package model.tests;

import model.DAOMap;
import org.junit.Test;

/**
 * @author ATOUGA II Emmanuel Désiré
 *
 */
public class DAOMapTest {


    DAOMap dao ;
    private String mapFile = "map.txt";

    /**
     * Test for level 0
     * @throws Exception
     */
    @Test(expected = Exception.class)
    public void testApplyToMap() throws Exception {
        this.dao.loadlevel(mapFile, "0");
    }

}