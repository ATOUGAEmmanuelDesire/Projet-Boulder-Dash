package contract;


/**
 * @author ATOUGA II Desire
 * @author groupe 10
 */
public interface IBoulderDashController {

	/**
     */
	void play();

	/**
	 * @return this
	 */
	IOrderPerformer getOrderPerformer();
}
