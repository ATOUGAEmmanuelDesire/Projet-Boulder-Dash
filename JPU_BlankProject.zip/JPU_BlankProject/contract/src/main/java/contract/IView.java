package contract;

import entity.fr.exia.showboard.BoardFrame;

/**
 * The Interface IView.
 *
 * @author AtougaIIDesire
 */
public interface IView {

	void displayMessage(final String message);

	void followMyPlayer();

	void updateView();

	BoardFrame getBoardFrame();
}