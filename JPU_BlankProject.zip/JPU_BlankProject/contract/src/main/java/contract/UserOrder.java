package contract;

public enum UserOrder {
    UP,
    DOWN,
    RIGHT,
    LEFT,
    NOP,
}
