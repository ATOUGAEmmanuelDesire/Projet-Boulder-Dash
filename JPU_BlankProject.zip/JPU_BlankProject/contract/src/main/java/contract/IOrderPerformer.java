package contract;

import java.io.IOException;

/**
 * @author AtougaII Emmanuel Désiré
 *
 */
public interface IOrderPerformer {

	/**
     */
	void orderPerform(UserOrder userOrder) throws IOException;

}