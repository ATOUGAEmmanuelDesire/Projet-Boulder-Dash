USE boulder_dash_2;


CREATE TABLE IF NOT EXISTS Lvs (
                                   Lv int DEFAULT NULL,
                                   map text
) ;

INSERT INTO lvs (Lv, map)
VALUES('1','
21
11
#####################
#..O..   O  * *     #
# * O.   O..      O.#
#     O   ..  OO   .#
# .G.   ...R. *O   .#
#################  .#
# ....             .#
# .O   ..O    ..G...#
#   ..R O*  ....**  #
#D **.. O* ..R..**  #
#####################');

INSERT INTO lvs (Lv, map)
VALUES ('2','
21
11
#####################
#..O..  O           #
###                .#
#       O           #
#  *        .....O. #
# .....             #
#  .G..    ##########
#             ..G...#
########....        #
# D  **         .R. #
#####################');

INSERT INTO lvs (Lv, map)
VALUES ('3','
21
11
#####################
#..O..  OO    *  #  #
############ O     .#
# R #   O  #   O    #
#  *#      #  ...O. #
# ..#..             #
#  .G..    ##########
#          #  ..G...#
########..*#       #
# D  **         ... #
#####################');
INSERT INTO lvs (Lv, map)
VALUES ('4','
21
11
#####################
#..O..  OO    *  #  #
############ O     .#
# R #   O  #   O    #
#  *#      #  ...O. #
# ..#..             #
#  .G..    ##########
#          #  ..G...#
########..*#       #
# D  **         ... #
#####################');


INSERT INTO lvs (Lv, map)
VALUES ('5','
21
11
#####################
#..O#.  OO #  *  #  #
#.. #      # O     .#
# R #   O  #   O    #
#  *#      #  ...O. #
# ..#..          D  #
#  .G..    ##########
#          #  ..G...#
##       ..*#       #
# D  **         ... #
#####################');

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `fetchMaps`()
    READS SQL DATA
    SQL SECURITY INVOKER
SELECT Valeur FROM Lvs WHERE Lv="1"$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getMapCode` (IN `p_id` INT)  READS SQL DATA
    SQL SECURITY INVOKER
SELECT Valeur FROM Lvs WHERE Lv="1"$$

DELIMITER ;



