package entity.motionless;

public class MotionlessElementFactory {
}
