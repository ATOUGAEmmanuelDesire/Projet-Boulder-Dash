package entity.motionless;

public class Permeability {
}
