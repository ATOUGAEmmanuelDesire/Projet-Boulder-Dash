package entity.motionless;

public class Sprite {
}
