package entity.motionless;

public interface IElement {
}
