package entity.motionless;

public class Element {
}
